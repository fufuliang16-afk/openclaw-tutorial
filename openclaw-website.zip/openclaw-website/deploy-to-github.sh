#!/bin/bash

# OpenClaw教学网站一键部署脚本
# 使用方法: ./deploy-to-github.sh YOUR_GITHUB_USERNAME

set -e  # 遇到错误时停止执行

echo "🚀 OpenClaw教学网站一键部署脚本"
echo "================================"

# 检查参数
if [ -z "$1" ]; then
    echo "❌ 错误: 请提供GitHub用户名"
    echo "使用方法: $0 YOUR_GITHUB_USERNAME"
    echo "示例: $0 octocat"
    exit 1
fi

GITHUB_USER="$1"
REPO_NAME="openclaw-tutorial"
REPO_URL="https://github.com/$GITHUB_USER/$REPO_NAME.git"
SITE_URL="https://$GITHUB_USER.github.io/$REPO_NAME"

echo "📦 准备部署到: $SITE_URL"
echo ""

# 检查是否在正确的目录
if [ ! -f "index.html" ] || [ ! -d "pages" ]; then
    echo "❌ 错误: 请在openclaw-website目录中运行此脚本"
    exit 1
fi

# 初始化Git仓库
echo "🔧 初始化Git仓库..."
if [ ! -d ".git" ]; then
    git init
    git config user.email "openclaw-tutorial@example.com"
    git config user.name "OpenClaw Tutorial"
    echo "✅ Git仓库已初始化"
else
    echo "⚠️  Git仓库已存在，跳过初始化"
fi

# 添加文件
echo "📝 添加文件到Git..."
git add .
echo "✅ 文件已添加"

# 提交更改
echo "💾 提交更改..."
git commit -m "部署OpenClaw教学网站 $(date '+%Y-%m-%d %H:%M:%S')" || echo "没有更改需要提交"
echo "✅ 更改已提交"

# 检查远程仓库
if git remote | grep -q "origin"; then
    echo "⚠️  远程仓库已存在，更新URL..."
    git remote set-url origin "$REPO_URL"
else
    echo "🔗 添加远程仓库..."
    git remote add origin "$REPO_URL"
fi

# 推送到GitHub
echo "🚀 推送到GitHub..."
git branch -M main
if git push -u origin main; then
    echo "✅ 代码已推送到GitHub"
else
    echo ""
    echo "❌ 推送失败！可能的原因："
    echo "   1. 仓库不存在 - 请先创建: https://github.com/new"
    echo "   2. 仓库名: $REPO_NAME"
    echo "   3. 确保仓库是公开的"
    echo "   4. 不要初始化README、.gitignore或许可证"
    echo ""
    echo "📋 手动创建仓库后，重新运行此脚本"
    exit 1
fi

echo ""
echo "🎉 代码推送完成！"
echo ""
echo "📋 下一步："
echo "   1. 访问: https://github.com/$GITHUB_USER/$REPO_NAME/settings/pages"
echo "   2. 在'Pages'设置中："
echo "      - Source: Deploy from a branch"
echo "      - Branch: main"
echo "      - Folder: / (root)"
echo "   3. 点击 Save"
echo ""
echo "⏳ 等待1-2分钟让GitHub Pages部署完成"
echo ""
echo "🌐 你的网站将发布在："
echo "   🔗 $SITE_URL"
echo ""
echo "📱 本地预览（部署期间可用）："
echo "   python3 -m http.server 8080"
echo "   然后访问: http://localhost:8080"
echo ""
echo "🔧 更新网站："
echo "   修改文件后，运行: git add . && git commit -m '更新' && git push"
echo ""
echo "📞 需要帮助？"
echo "   - GitHub文档: https://docs.github.com/pages"
echo "   - OpenClaw社区: https://discord.com/invite/clawd"