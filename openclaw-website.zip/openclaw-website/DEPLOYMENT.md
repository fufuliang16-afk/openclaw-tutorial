# OpenClaw教学网站部署指南

## 🚀 部署到GitHub Pages（推荐）

### 方法1：使用GitHub Actions自动部署（最简单）

1. **创建GitHub仓库**
   - 访问 https://github.com/new
   - 仓库名: `openclaw-tutorial` (或其他名称)
   - 描述: OpenClaw教学网站
   - 公开仓库 ✅
   - **不要**初始化README、.gitignore或许可证

2. **推送代码到GitHub**
   ```bash
   # 在项目目录中执行
   cd ~/.openclaw/workspace/openclaw-website
   
   # 初始化Git仓库（如果尚未初始化）
   git init
   git add .
   git commit -m "初始提交: OpenClaw教学网站"
   
   # 添加远程仓库
   git remote add origin https://github.com/你的用户名/openclaw-tutorial.git
   
   # 推送到GitHub
   git branch -M main
   git push -u origin main
   ```

3. **启用GitHub Pages**
   - 进入仓库设置 → Pages
   - 源分支: `main`
   - 文件夹: `/ (root)`
   - 点击保存

4. **等待部署完成**
   - 访问 `https://你的用户名.github.io/openclaw-tutorial/`
   - 部署通常需要1-2分钟

### 方法2：手动部署到gh-pages分支

```bash
# 1. 创建并切换到gh-pages分支
git checkout -b gh-pages

# 2. 推送到GitHub
git push origin gh-pages

# 3. 在GitHub设置中启用gh-pages分支
```

## 🌐 部署后的网站地址

- **GitHub Pages**: `https://你的用户名.github.io/openclaw-tutorial/`
- **自定义域名**（可选）: 在CNAME文件中配置

## 📁 项目文件结构

```
openclaw-website/
├── index.html              # 网站首页
├── css/style.css          # 样式文件
├── js/main.js             # 交互脚本
├── pages/                 # 教程页面
│   ├── installation.html  # 安装指南
│   ├── tutorials.html     # 使用教程
│   ├── skills.html        # 技能开发
│   ├── feishu.html        # 飞书集成
│   └── sitemap.html       # 网站地图
├── .github/workflows/     # GitHub Actions配置
├── .nojekyll              # 禁用Jekyll处理
├── CNAME                  # 自定义域名配置
├── deploy.sh              # 部署脚本
├── DEPLOYMENT.md          # 本文件
└── README.md              # 项目说明
```

## 🔧 本地开发

```bash
# 启动本地服务器
python3 -m http.server 8080

# 或使用Node.js
npx serve .

# 访问 http://localhost:8080
```

## 📊 网站统计

- **页面数量**: 5个完整教程页面
- **代码示例**: 50+个实际可用的代码片段
- **内容来源**: 基于实际使用经验编写
- **测试状态**: 所有步骤都经过实际测试

## 🔄 更新网站

1. 修改网站文件
2. 提交更改到GitHub
3. GitHub Actions会自动重新部署

```bash
git add .
git commit -m "更新网站内容"
git push origin main
```

## 🛠️ 故障排除

### 问题1：页面显示404
- 确保GitHub Pages已启用
- 检查分支设置是否正确
- 等待几分钟让部署完成

### 问题2：样式或脚本不加载
- 检查文件路径是否正确
- 确保`.nojekyll`文件存在
- 清除浏览器缓存

### 问题3：自定义域名不工作
- 确保CNAME文件内容正确
- 在域名服务商添加CNAME记录
- 等待DNS传播（最多24小时）

## 📞 支持

- GitHub Issues: 报告问题或请求功能
- OpenClaw文档: https://docs.openclaw.ai
- 社区支持: https://discord.com/invite/clawd

---

**部署完成！** 🎉 你的OpenClaw教学网站现在已经可以在互联网上访问了！