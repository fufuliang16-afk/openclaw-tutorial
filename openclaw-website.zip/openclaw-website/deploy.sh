#!/bin/bash

# OpenClaw教学网站部署脚本

echo "🚀 OpenClaw教学网站部署脚本"
echo "=============================="

# 检查是否在Git仓库中
if [ ! -d ".git" ]; then
    echo "❌ 当前目录不是Git仓库"
    echo "正在初始化Git仓库..."
    git init
    git add .
    git commit -m "初始提交: OpenClaw教学网站"
fi

# 检查远程仓库
if ! git remote | grep -q "origin"; then
    echo "⚠️  未设置远程仓库"
    echo "请先添加远程仓库:"
    echo "  git remote add origin <你的GitHub仓库URL>"
    exit 1
fi

# 构建检查
echo "📦 检查网站文件..."
if [ ! -f "index.html" ]; then
    echo "❌ 找不到index.html文件"
    exit 1
fi

if [ ! -d "css" ]; then
    echo "❌ 找不到css目录"
    exit 1
fi

if [ ! -d "js" ]; then
    echo "❌ 找不到js目录"
    exit 1
fi

echo "✅ 网站文件检查通过"

# 提交更改
echo "📝 提交更改..."
git add .
git commit -m "更新网站内容 $(date '+%Y-%m-%d %H:%M:%S')" || echo "没有更改需要提交"

# 推送到GitHub Pages
echo "🚀 部署到GitHub Pages..."
echo "选择部署分支:"
echo "1) main分支 (直接部署)"
echo "2) gh-pages分支 (GitHub Pages专用)"
read -p "请选择 (1/2): " branch_choice

case $branch_choice in
    1)
        echo "推送到main分支..."
        git push origin main
        echo "✅ 部署完成！网站地址: https://<你的用户名>.github.io/<仓库名>/"
        ;;
    2)
        echo "推送到gh-pages分支..."
        # 创建并切换到gh-pages分支
        git checkout -b gh-pages 2>/dev/null || git checkout gh-pages
        git push origin gh-pages
        echo "✅ 部署完成！网站地址: https://<你的用户名>.github.io/<仓库名>/"
        ;;
    *)
        echo "❌ 无效选择"
        exit 1
        ;;
esac

echo ""
echo "🎉 部署完成！"
echo "📚 下一步："
echo "  1. 在GitHub仓库设置中启用GitHub Pages"
echo "  2. 选择部署分支 (main 或 gh-pages)"
echo "  3. 等待几分钟让GitHub构建完成"
echo "  4. 访问你的网站！"
echo ""
echo "🔧 本地预览："
echo "  npm start  # 启动本地服务器"
echo "  npm run dev  # 使用live-server（支持热重载）"