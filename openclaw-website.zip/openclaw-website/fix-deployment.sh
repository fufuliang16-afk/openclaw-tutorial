#!/bin/bash

# OpenClaw教学网站部署修复脚本
# 解决GitHub Pages 404问题

echo "🔧 OpenClaw教学网站部署修复脚本"
echo "================================="

# 检查是否在正确目录
if [ ! -f "index.html" ] || [ ! -d "pages" ]; then
    echo "❌ 错误：请在openclaw-website目录中运行"
    exit 1
fi

echo "📊 诊断问题..."
echo "1. 检查本地文件... ✅"
echo "2. 检查Git配置..."

# 检查Git配置
if [ ! -d ".git" ]; then
    echo "❌ Git仓库未初始化"
    echo "正在初始化Git仓库..."
    git init
    git config user.email "openclaw-tutorial@example.com"
    git config user.name "OpenClaw Tutorial"
fi

# 设置远程仓库
echo "🔗 设置远程仓库..."
git remote remove origin 2>/dev/null
git remote add origin https://github.com/fufuliang16-afk/openclaw-tutorial.git

echo "📦 准备上传文件..."
echo "需要上传的文件："
echo "  • index.html (网站首页)"
echo "  • css/style.css (样式文件)"
echo "  • js/main.js (交互脚本)"
echo "  • pages/ (5个教程页面)"
echo "  • .nojekyll (禁用Jekyll)"
echo "  • 其他配置文件"

echo ""
echo "🚀 开始修复部署..."
echo ""
echo "请按照以下步骤操作："
echo ""
echo "步骤1：打开GitHub仓库"
echo "  访问：https://github.com/fufuliang16-afk/openclaw-tutorial"
echo ""
echo "步骤2：上传缺失的文件"
echo "  点击 'Add file' → 'Upload files'"
echo "  上传以下文件："
echo "    1. index.html"
echo "    2. css/ 文件夹"
echo "    3. js/ 文件夹"
echo "    4. pages/ 文件夹"
echo "    5. 其他根目录文件"
echo ""
echo "步骤3：启用GitHub Pages"
echo "  访问：https://github.com/fufuliang16-afk/openclaw-tutorial/settings/pages"
echo "  配置："
echo "    • Source: Deploy from a branch"
echo "    • Branch: main"
echo "    • Folder: / (root)"
echo "    • 点击 Save"
echo ""
echo "步骤4：等待部署"
echo "  等待2-3分钟"
echo "  访问：https://fufuliang16-afk.github.io/openclaw-tutorial/"
echo ""
echo "📋 如果还是404："
echo "  1. 确保所有文件都已上传"
echo "  2. 检查是否有 .nojekyll 文件"
echo "  3. 重新配置GitHub Pages"
echo "  4. 清除浏览器缓存"
echo ""
echo "🎯 关键检查点："
echo "  ✅ index.html 必须存在"
echo "  ✅ .nojekyll 必须存在"
echo "  ✅ GitHub Pages 必须启用"
echo "  ✅ 分支必须是 main"
echo ""
echo "🔗 你的网站地址："
echo "  https://fufuliang16-afk.github.io/openclaw-tutorial/"
echo ""
echo "📞 需要帮助？"
echo "  查看 FIX_DEPLOYMENT.md 文件获取详细指南"